import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, 'data', 'db.json');
const app = express();
app.use(cors());
app.use(express.json());

const readDb = () => JSON.parse(fs.readFileSync(dbPath, 'utf8'));
const writeDb = db => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

function scoreMatch(student, opportunity) {
  const req = opportunity.requiredSkills || {};
  const skills = student.skills || {};
  const entries = Object.entries(req);
  if (!entries.length) return 0;
  let total = 0;
  for (const [skill, need] of entries) total += Math.min((skills[skill] || 0) / need, 1) * 100;
  return Math.round(total / entries.length);
}
function reasons(student, opportunity) {
  const req = opportunity.requiredSkills || {};
  const skills = student.skills || {};
  return Object.entries(req).map(([skill, need]) => {
    const have = skills[skill] || 0;
    return have >= need ? `${skill}: requirement met (${have}/${need})` : `${skill}: gap ${need-have} points (${have}/${need})`;
  });
}

app.get('/api/health', (_, res) => res.json({ok:true, product:'AYUSH CONNECT'}));
app.get('/api/users/:id', (req,res)=>{
  const db=readDb(); const user=db.users.find(u=>u.id===Number(req.params.id));
  user ? res.json(user) : res.status(404).json({error:'User not found'});
});
app.post('/api/login',(req,res)=>{
  const db=readDb(); const user=db.users.find(u=>u.email.toLowerCase()===String(req.body.email||'').toLowerCase());
  if(!user) return res.status(401).json({error:'Demo account not found'});
  res.json(user);
});
app.post('/api/assessment',(req,res)=>{
  const db=readDb(); const user=db.users.find(u=>u.id===Number(req.body.userId));
  if(!user) return res.status(404).json({error:'Student not found'});
  user.skills=req.body.skills || user.skills;
  const role = req.body.targetRole || user.targetRole || 'Full Stack Developer';
  user.targetRole=role;
  const roleReq={
    'Full Stack Developer':{JavaScript:80,React:80,'Node.js':70,SQL:70,Git:60},
    'Frontend Developer':{JavaScript:80,React:80,Git:60},
    'Backend Developer':{'Node.js':75,SQL:75,Git:60}
  }[role] || {JavaScript:70,SQL:70,Git:60};
  let sum=0; let gaps=[];
  for(const [s,n] of Object.entries(roleReq)){ const have=user.skills[s]||0; sum+=Math.min(have/n,1)*100; if(have<n) gaps.push({skill:s,required:n,current:have,gap:n-have}); }
  user.readiness=Math.round(sum/Object.keys(roleReq).length);
  writeDb(db); res.json({user, gaps, roleRequirements:roleReq});
});
app.get('/api/opportunities',(req,res)=>{
  const db=readDb(); const studentId=Number(req.query.studentId);
  const student=db.users.find(u=>u.id===studentId);
  const list=db.opportunities.map(o=>({...o, match:student?scoreMatch(student,o):null, reasons:student?reasons(student,o):[]})).sort((a,b)=>(b.match??0)-(a.match??0));
  res.json(list);
});
app.post('/api/applications',(req,res)=>{
  const db=readDb();
  const exists=db.applications.find(a=>a.userId===Number(req.body.userId)&&a.opportunityId===Number(req.body.opportunityId));
  if(exists) return res.status(409).json({error:'Already applied'});
  const opp=db.opportunities.find(o=>o.id===Number(req.body.opportunityId));
  const student=db.users.find(u=>u.id===Number(req.body.userId));
  if(!opp||!student) return res.status(400).json({error:'Invalid application'});
  const application={id:Date.now(),userId:student.id,student:student.name,opportunityId:opp.id,opportunity:opp.title,company:opp.company,match:scoreMatch(student,opp),status:'Applied',createdAt:new Date().toISOString()};
  db.applications.push(application); writeDb(db); res.json(application);
});
app.get('/api/applications',(req,res)=>{
  const db=readDb(); const userId=Number(req.query.userId);
  res.json(db.applications.filter(a=>!userId||a.userId===userId));
});
app.get('/api/college-analytics',(req,res)=>{
  const db=readDb(); const students=db.users.filter(u=>u.role==='student');
  res.json({students:students.length,avgReadiness:Math.round(students.reduce((s,u)=>s+(u.readiness||0),0)/(students.length||1)),applications:db.applications.length,topSkills:['JavaScript','SQL','Git']});
});
app.get('/api/industry-applicants',(req,res)=>{
  const db=readDb(); res.json(db.applications.map(a=>({...a,studentProfile:db.users.find(u=>u.id===a.userId)})));
});

app.listen(5000,()=>console.log('AYUSH CONNECT API running on http://localhost:5000'));
