CREATE DATABASE IF NOT EXISTS ayush_connect;
USE ayush_connect;
CREATE TABLE users(id INT PRIMARY KEY AUTO_INCREMENT,name VARCHAR(120),email VARCHAR(160) UNIQUE,role ENUM('student','industry','college') NOT NULL,college VARCHAR(160),company VARCHAR(160),target_role VARCHAR(120),readiness INT DEFAULT 0);
CREATE TABLE skills(id INT PRIMARY KEY AUTO_INCREMENT,name VARCHAR(100) UNIQUE NOT NULL);
CREATE TABLE user_skills(user_id INT,skill_id INT,score INT,PRIMARY KEY(user_id,skill_id),FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(skill_id) REFERENCES skills(id));
CREATE TABLE opportunities(id INT PRIMARY KEY AUTO_INCREMENT,title VARCHAR(180),company VARCHAR(160),location VARCHAR(120),type VARCHAR(50),description TEXT);
CREATE TABLE opportunity_skills(opportunity_id INT,skill_id INT,required_score INT,PRIMARY KEY(opportunity_id,skill_id),FOREIGN KEY(opportunity_id) REFERENCES opportunities(id),FOREIGN KEY(skill_id) REFERENCES skills(id));
CREATE TABLE applications(id INT PRIMARY KEY AUTO_INCREMENT,user_id INT,opportunity_id INT,match_score INT,status VARCHAR(40) DEFAULT 'Applied',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
