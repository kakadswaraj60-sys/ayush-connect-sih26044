# AYUSH CONNECT — SIH26044

Explainable Skill Intelligence Platform for Academia–Industry Collaboration.

## MVP flow
Student → Assessment → Skill Gap → Learn → Match → Apply → Track

## Tech
- Frontend: React + Vite
- Backend: Node.js + Express
- Persistence: JSON file for zero-setup demo
- Production DB: MySQL schema included in `backend/schema.sql`

## Run
### Backend
```bash
cd backend
npm install
npm run dev
```
Runs on http://localhost:5000

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Runs on http://localhost:5173

## Demo accounts
- Student: student@demo.com
- Industry: industry@demo.com
- College: college@demo.com

No password is required in this MVP demo login.

## Winning demo
1. Login as Student
2. Open Skill Assessment and submit scores
3. Select Full Stack Developer target role
4. See explainable skill gaps and readiness score
5. Open Opportunities and see match percentages/reasons
6. Apply to an opportunity
7. Login as Industry and review applicant
8. Login as College and see readiness/application analytics
